const puppeteer = require('puppeteer');
module.exports = {};

async function findShoe(shoe, cb) {
    name = shoe.name.replace(/\s+/g, '-').toLowerCase();
    var url = 'https://teststorehypeshoes.myshopify.com/products/' + name;
    console.log(url);
    const browser = await puppeteer.launch( {headless : true});
    const page = await browser.newPage();
    page.setUserAgent('Mozilla/5.0 (Macintosh; Intel Mac OS X 10.14; rv:66.0) Gecko/20100101 Firefox/66.0');

    var response = await page.goto(url);
    console.log(response.status());
    if(response.status() != '200'){
        console.log('Match not found yet...');
        await browser.close();
        return cb('Match not found yet...', null);
    }
    await page.waitForSelector('#SingleOptionSelector-0');
    for(let i=0;i<shoe.sizes.length;i++){
        await page.select('#SingleOptionSelector-0', shoe.sizes[i].size);
        await page.waitFor(100);
        try{
            await page.waitForSelector('[data-shopify="payment-button"]', { visible: true, timeout:1000});
        } catch(e){
            console.log("Size " + shoe.sizes[i].size + " not found");
            continue;
        }
        console.log("Choosing size: " + shoe.sizes[i].size);
        url = await page.url();

        styleID = url.split('variant=')[1];
        console.log(styleID);
        await browser.close();
        return cb(null, styleID);
    }
    await browser.close();
    return cb('Match not found yet...', null);

}

module.exports.findShoe = findShoe;