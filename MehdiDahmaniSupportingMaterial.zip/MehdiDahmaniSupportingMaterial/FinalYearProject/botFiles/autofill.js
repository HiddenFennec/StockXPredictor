const puppeteer = require('puppeteer');

module.exports = {};

async function pay(shoe, styleID, qty, config) {
     const browser = await puppeteer.launch( {headless : false});
    const page = await browser.newPage();
    page.setUserAgent('Mozilla/5.0 (Macintosh; Intel Mac OS X 10.14; rv:66.0) Gecko/20100101 Firefox/66.0');
    var url = 'https://teststorehypeshoes.myshopify.com/cart/add.js';
    await page.setRequestInterception(true);

    page.on('request', request => {
        if (!request.isNavigationRequest()) {
            request.continue();
            return;
        }
        const headers = request.headers();
        headers['Origin'] = 'https://teststorehypeshoes.myshopify.com';
        headers['Content-Type'] = 'application/x-www-form-urlencoded';
        headers['Accept'] = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8';
        headers['Referer'] = 'https://teststorehypeshoes.myshopify.com/products/' + shoe.name.replace(/\s+/g, '-').toLowerCase();
        headers['Accept-Language'] = 'en-GB,en;q=0.5';
        var data = {
            'followAllRedirects': true,
            'method': 'POST',
            'headers': headers,
            'postData': 'id='+styleID+'&quantity='+ qty
        };
        request.continue(data);
    });

    await page.goto(url);
    url = 'https://teststorehypeshoes.myshopify.com/cart';
    const page1 = await browser.newPage();
    page.close();
    
    const resp = await page1.goto(url);

    await page1.waitForSelector('[name="checkout"');
    const element = await page1.$('[name="checkout"]');
    await element.click();
    

    await page1.waitForNavigation();
    if(page1.url().indexOf("stock_problems") > -1){
        const element = await page1.$('#continue-shopping');
        await element.click();
        await page1.waitForNavigation();
    }
    

    
    await page1.evaluate((email) => { (document.getElementsByName('checkout[email_or_phone]')[0]).value = email; }, config['email']);
    
    await page1.evaluate((firstName) => { (document.getElementById('checkout_shipping_address_first_name')).value = firstName; }, config['firstName']);

    await page1.evaluate((lastName) => { (document.getElementById('checkout_shipping_address_last_name')).value = lastName; }, config['lastName']);

    await page1.evaluate((firstAddress) => { (document.getElementById('checkout_shipping_address_address1')).value = firstAddress; }, config['firstAddress']);

    await page1.evaluate((secondAddress) => { (document.getElementById('checkout_shipping_address_address2')).value = secondAddress; }, config['secondAddress']);

    await page1.evaluate((city) => { (document.getElementById('checkout_shipping_address_city')).value = city; }, config['city']);
    
    await page1.evaluate((postal) => { (document.getElementById('checkout_shipping_address_zip')).value = postal; }, config['postal']);

    
    await page1.focus('#checkout_shipping_address_country');
    await page1.select('#checkout_shipping_address_country', config['country']);
    
    const submit = await page1.$('#continue_button');
    await submit.click();
    await page1.waitForSelector('#checkout_shipping_rate_id_shopify-standard20shipping-10_00');
    const submitShipping = await page1.$('#continue_button');
    await submitShipping.click();

    await page1.waitForNavigation();

    await page1.setRequestInterception(true);
    page1.on('request', request => {
        if(request.url().startsWith('https://elb.deposit.shopifycs.com/sessions')){
            let payload = {
                "credit_card":
                {
                    "number": config['cardNum'],
                    "name":config['cardName'],
                    "start_month": ((config['issueDate']) ? config['issueDate'].substring(0,2): null),
                    "start_year":((config['issueDate']) ? config['issueDate'].substring(3,5): null),
                    "month":config['cardExpire'].substring(0,2),
                    "year":"20" + config['cardExpire'].substring(3,5),
                    "verification_value":config['ccv'],
                    "issue_number":config['issue']
                }
            };

            var data = {
                'method': 'POST',
                'postData': JSON.stringify(payload) 
            }
            request.continue(data);
        } else {
            request.continue();
        }
    });
    console.log("complete!");
}
module.exports.pay = pay;

