In order to get program working:

1. go to terminal and go to the working directory (where all files are).
2. run 'npm install'
3. run 'npm start'

If you see a blank screen its because the server is not on. You need to create a server as per the implementation and copy and paste the shoes.json link into the shoesURL input in the Edit Profile window in the desktop application and click Refresh.
